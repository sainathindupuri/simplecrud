package com.dep.controller;

import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import java.io.IOException;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.jboss.logging.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.View;

import com.dep.model.Department;
import com.dep.service.ItemService;



@Controller

public class ItemController {
	

	public ItemController() {
	}
	
	@RequestMapping(value="/")
	public String home() {
		return "Welcome";
	}

	@Autowired(required = true)
	private ItemService service;


	@RequestMapping(value = "/DepList")
	private String DepList(Model model) throws IOException {
		// TODO Auto-generated method stub

		List<Department> depList = service.depList();
		model.addAttribute("dep_list", depList);
		//model.setViewName("ListDepartments");
		return "ListDepartments";

	}

	@RequestMapping(value = "/ShowDepForm")
	private ModelAndView ShowDepForm(Model model) throws IOException {

		return new ModelAndView("DepartmentCreation","command",new Department());
	}

	@RequestMapping(value = "/createDep", method = RequestMethod.POST)
	private String createDep(@ModelAttribute Department dep) throws IOException {

		service.createDep(dep);
		return "redirect:/DepList";

	}

	@RequestMapping(value = "/deleteDepartment/{id}")
	private String deleteDepartment(@ModelAttribute Department dep, @PathVariable("id") int id)
			throws IOException {

		System.out.println(id);
		service.deleteDep(id);
		return "redirect:/DepList";

	}

	

	@RequestMapping(value = "/editDepartment/{id}")
	private ModelAndView editDepartment(@PathVariable("id") int id, Model model) throws IOException {

		Department dep = service.getDep(id);
		model.addAttribute("Dep", dep);
		return new ModelAndView("EditDep", "command", new Department());
	}

	@RequestMapping(value = "/editDepartment/updateDep", method = RequestMethod.POST)
	private ModelAndView updateDep(@ModelAttribute Department dep) throws IOException {

		System.out.println(dep.getId() + "Name:" + dep.getName() + "sample");
		System.out.println(dep.getName());
		service.updateDep(dep);
		return new ModelAndView("redirect:/DepList");
	}

}
