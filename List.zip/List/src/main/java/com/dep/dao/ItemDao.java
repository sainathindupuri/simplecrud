package com.dep.dao;

import java.util.List;

import com.dep.model.Department;



public interface ItemDao {
	
	
	public void createDep(Department dep);
	
	public List<Department> depList();
	
	public Department getDep(int id);
	
	public void deleteDep(Department dep);
	
	public void updateDep(Department dep);

}
