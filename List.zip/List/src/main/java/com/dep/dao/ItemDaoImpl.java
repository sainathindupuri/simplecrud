package com.dep.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;
import org.hibernate.service.ServiceRegistry;
import org.springframework.stereotype.Repository;

import com.dep.model.Department;

@Repository("dao")
public class ItemDaoImpl implements ItemDao {


	public ItemDaoImpl() {
		super();
	}

	@PersistenceContext
	private EntityManager em;

	
	public void createDep(Department dep) {
		em.persist(dep);
	}

	public List<Department> depList() {
		List<Department> list = new ArrayList<Department>();
		Query query = em.createQuery("from Department", Department.class);
		list = (List<Department>) query.getResultList();
		return list;
	}

	public Department getDep(int id) {
		Department dep = new Department();
		dep = em.find(Department.class, id);
		return dep;
	}
	
	public void deleteDep(Department dep) {
		em.remove(dep);
	}

	public void updateDep(Department dep) {

		Department obj = em.find(Department.class, dep.getId());
		obj.setName(dep.getName());

	}

}
