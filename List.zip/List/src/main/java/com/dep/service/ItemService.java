package com.dep.service;

import java.util.List;

import com.dep.model.Department;



public interface ItemService {
	
	public void createDep(Department dep);
	
	public List<Department> depList(); 
	
	public Department getDep(int id);
	
	public void deleteDep(int id);
	
	public void updateDep(Department dep);

}
