package com.dep.service;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.dep.dao.ItemDao;
import com.dep.model.Department;

@Service("service")
public class ItemServiceImpl implements ItemService {

	public void ItemServiceImpl() {

	}

	@Autowired(required = true)
	public ItemDao dao;

	@Transactional
	public void createDep(Department dep) {
		// TODO Auto-generated method stub

		dao.createDep(dep);
	}

	@Transactional
	public List<Department> depList() {
		// TODO Auto-generated method stub

		List<Department> depList = dao.depList();
		return depList;
	}

	@Transactional
	public Department getDep(int id) {
		// TODO Auto-generated method stub

		Department dep = dao.getDep(id);
		return dep;
	}

	@Transactional
	public void deleteDep(int id) {
		// TODO Auto-generated method stub

		Department dep = dao.getDep(id);
		System.out.println("department to be deleted is =" + dep.getId());
		dao.deleteDep(dep);

	}

	@Transactional
	public void updateDep(Department dep) {
		// TODO Auto-generated method stub

		dao.updateDep(dep);

	}

}
